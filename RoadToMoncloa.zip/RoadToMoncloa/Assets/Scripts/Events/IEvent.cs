﻿public interface IEvent
{
}