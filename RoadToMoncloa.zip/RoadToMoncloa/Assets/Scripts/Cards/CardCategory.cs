﻿public enum CardCategory
{
    Education,
    Development,
    Economy,
    ForeignPolicy,
    Health,
    Technology,
    Transport
}