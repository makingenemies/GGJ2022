public static class Tags
{
    public const string VotersCardDropZone = nameof(VotersCardDropZone);
    public const string MoneyCardDropZone = nameof(MoneyCardDropZone);
    public const string LiesBox = nameof(LiesBox);
}
