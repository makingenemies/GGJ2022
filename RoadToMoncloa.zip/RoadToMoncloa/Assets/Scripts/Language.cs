using System.Collections.Generic;

public enum Language
{
    Spanish = 0,
}
