public enum CardPlayType
{
    Voters = 0,
    Money = 1,
    Lies = 2,
}