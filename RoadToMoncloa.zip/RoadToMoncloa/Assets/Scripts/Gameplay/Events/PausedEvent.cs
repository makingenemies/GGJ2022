﻿public class PausedEvent : IEvent
{
}