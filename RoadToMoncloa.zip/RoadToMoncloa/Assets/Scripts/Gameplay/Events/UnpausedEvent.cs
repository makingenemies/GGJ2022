﻿public class UnpausedEvent : IEvent
{
}