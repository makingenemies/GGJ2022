﻿public class LiesResetEvent : IEvent
{
}