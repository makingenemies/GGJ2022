﻿public class LiePlayedEvent : IEvent
{
    public bool IsLiesCounterFull { get; set; }
}